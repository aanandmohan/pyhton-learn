'''Find common elements in three sorted arrays.
Given three arrays sorted in increasing order. Find the elements that are common in all three arrays.
Note: can you take care of the duplicates without using any additional Data Structure?
Example 1:
Input:
n1 = 6; A = {1, 5, 10, 20, 40, 80}
n2 = 5; B = {6, 7, 20, 80, 100}
n3 = 8; C = {3, 4, 15, 20, 30, 70, 80, 120}
Output: 20 80
Explanation: 20 and 80 are the only
common elements in A, B and C'''
a=[]
b=[]
c=[]
n=int(input("enter n "))
for i in range(n):
    x=int(input("enter elemnt "))
    a.append(x)
n1=int(input("enter n2 "))
for i in range(n1):
    x=int(input("enter elemnt "))
    b.append(x)
n2=int(input("enter n2 "))
for i in range(n2):
    x=int(input("enter elemnt "))
    c.append(x)
out=""
for i in a:
    if i in b and i in c:
        out+=str(i)+" "

print("the output is ",out)